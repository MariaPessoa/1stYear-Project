# -*- coding: utf-8 -*-
"""
Created on Mon Jul 13 12:34:46 2020

@author: liamo
"""
from cobra.io import read_sbml_model,write_sbml_model 
from cobra.flux_analysis import find_essential_reactions,flux_variability_analysis
from cobra.flux_analysis import pfba
import pandas as pd
import numpy as np

ROOT_FOLDER = "C:\\Users\\liamo\\Documents\\BIOINF\\PROJ\\files"  
MORE_MODELS = ROOT_FOLDER + "\\results\\" + "r3d_log2_MOREDATA_fastcore.csv"
MODEL_PATH = ROOT_FOLDER + '\\Recon3D_301_ct.xml'  

mdread = pd.read_csv(MORE_MODELS,header=0,sep=",").iloc[:,2:]
mdheader = list(mdread.columns.values)

model = read_sbml_model(MODEL_PATH) 
model.objective = "biomass_reaction"
reactions = list(model.reactions) 
essential = list(find_essential_reactions(model,processes=2)) 
print("Essential Consistent:",len(essential)) #3
essential_ids = []
for i in range(len(essential)): essential_ids.append(essential[i].id)
unfeasible = np.array([-1]*len(reactions)).reshape(len(reactions),)

fva_df = np.zeros((len(reactions),mdread.shape[0]*2))
fva_hypoxia_df = np.zeros((len(reactions),mdread.shape[0]*2))
pfba_df = np.zeros((len(reactions),mdread.shape[0]))
pfba_hypoxia_df = np.zeros((len(reactions),mdread.shape[0]))

for m in range(mdread.shape[0]):
    model_b2 = read_sbml_model(MODEL_PATH) 
    model_b2.objective = "biomass_reaction" 
    # if m < 2: model_b2.objective = "biomass_reaction" 
    # else: model_b2.objective = "biomass_maintenance" 
    ct = 0
    for r in range(len(mdheader)):
        if (mdread.iloc[m,r] == False) and (mdheader[r] not in essential_ids):
            model_b2.reactions.get_by_id(mdheader[r]).bounds = (0,0) 

    fba = model_b2.optimize()
    if fba.status == "optimal":    
        try:
            results_pfba = np.array(pfba(model_b2).fluxes)
            pfba_df[:,m] = results_pfba
        except:
            pfba_df[:,m] = unfeasible
        
        model_b2.reactions.get_by_id("EX_o2[e]").bounds = (0,1000) 
        try:
            results_hypoxia_pfba = np.array(pfba(model_b2).fluxes)
            pfba_hypoxia_df[:,m] = results_hypoxia_pfba
        except:
            pfba_hypoxia_df[:,m] = unfeasible
            
        model_b2.reactions.get_by_id("EX_o2[e]").bounds = (-1000,1000) 
        try:
            results_fva = np.array(flux_variability_analysis(model_b2,fraction_of_optimum=0.1))
        except:
            results_fva = np.concatenate((unfeasible,unfeasible),axis=1)
            
        model_b2.reactions.get_by_id("EX_o2[e]").bounds = (0,1000) 
        try:
            results_hypoxia_fva = np.array(flux_variability_analysis(model_b2,fraction_of_optimum=0.1))
        except:
            results_hypoxia_fva = np.concatenate((unfeasible,unfeasible),axis=1)
        
        fva_df[:,(m*2):(m*2)+2] = results_fva
        fva_hypoxia_df[:,(m*2):(m*2)+2] = results_hypoxia_fva
    else: 
        pfba_df[:,m] = unfeasible
        pfba_hypoxia_df[:,m] = unfeasible
        fva_df[:,(m*2):(m*2)+2] = np.concatenate((unfeasible,unfeasible),axis=1)
        fva_hypoxia_df[:,(m*2):(m*2)+2] = np.concatenate((unfeasible,unfeasible),axis=1)

#OUTPUT
MORE_MODELS_FVA = ROOT_FOLDER + "\\results\\" + "md_fva.csv"
MORE_MODELS_FVA_HYP = ROOT_FOLDER + "\\results\\" + "md_fva_hyp.csv"
MORE_MODELS_pfba = ROOT_FOLDER + "\\results\\" + "md_pfba.csv"
MORE_MODELS_pfba_hyp = ROOT_FOLDER + "\\results\\" + "md_pfba_hyp.csv"

fva_df = pd.DataFrame(fva_df)
fva_hypoxia_df = pd.DataFrame(fva_hypoxia_df)
fva_df.to_csv(MORE_MODELS_FVA)
fva_hypoxia_df.to_csv(MORE_MODELS_FVA_HYP)

pfba_df = pd.DataFrame(pfba_df)
pfba_hypoxia_df = pd.DataFrame(pfba_hypoxia_df)
pfba_df.to_csv(MORE_MODELS_pfba)
pfba_hypoxia_df.to_csv(MORE_MODELS_pfba_hyp)
