# -*- coding: utf-8 -*-
"""
Created on Wed Jul 15 09:22:02 2020

@author: liamo
"""
from cobra.io import read_sbml_model, load_matlab_model
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
    
# if __name__ == '__main__':
ROOT_FOLDER = "C:\\Users\\liamo\\Documents\\BIOINF\\PROJ\\files"  
MODEL_PATH = ROOT_FOLDER + '\\Recon3D_301_ct.xml'  
MODEL_MAT_PATH = ROOT_FOLDER + '\\Recon3D.mat'
MORE_MODELS = ROOT_FOLDER + "\\results\\" + "r3d_log2_MOREDATA_fastcore.csv"
MORE_MODELS_TASKS = ROOT_FOLDER + "\\results\\" + "r3d_log2_MOREDATA_task_results.json"
MORE_MODELS_FVA = ROOT_FOLDER + "\\results\\" + "md_fva.csv"
MORE_MODELS_FVA_HYP = ROOT_FOLDER + "\\results\\" + "md_fva_hyp.csv"
MORE_MODELS_pfba = ROOT_FOLDER + "\\results\\" + "md_pfba.csv"
MORE_MODELS_pfba_hyp = ROOT_FOLDER + "\\results\\" + "md_pfba_hyp.csv"

mdread = pd.read_csv(MORE_MODELS,header=0,sep=",").iloc[:,2:]
mdheader = list(mdread.columns.values)

#checking for reconstruction issues, ex: all reactions set to False
#counts True
print(np.sum(np.any(mdread,axis=0)),
      round(np.sum(np.any(mdread,axis=0))/mdread.shape[1]*100),"%")
#check if biomass_reaction set to False - counts False / should be 0
print(mdread.shape[0]-np.sum(mdread.iloc[:,5440]))

print("Average GBM reaction count:",round(np.mean(np.sum(mdread.iloc[:2,:],axis=1))),"\n",
      "Average AST reaction count:",round(np.mean(np.sum(mdread.iloc[2:,],axis=1))),"\n",
      "GBM Recon3D total reaction %:",round(np.mean(np.sum(mdread.iloc[:2,:],axis=1))/11961*100),"\n",
      "AST Recon3D total reaction %:",round(np.mean(np.sum(mdread.iloc[2:,:],axis=1))/11961*100)) 

################## RECON3D #####################
model = read_sbml_model(MODEL_PATH) 
model.objective = "biomass_reaction" #biomass_maintenance
model_fba = model.optimize()

# PATHWAYs / subsystems (.mat model)
model_mat = load_matlab_model(MODEL_MAT_PATH)
reactions = list(model.reactions) #sbml
sinks = list(model.sinks) #sbml ct 94 vs mat 92
sinks_indexs = []
for s in sinks: sinks_indexs.append(reactions.index(s))
reaction_ids = []
mat_ids = []
for r in list(model_mat.reactions): mat_ids.append(r.id)
subsystems = [] 
for r in reactions:
    reaction_ids.append(r.id)
    if r.id in mat_ids:
        subsystems.append(model_mat.reactions.get_by_id(r.id).subsystem)
    else: subsystems.append("Unknown") #3714
# subsarray = pd.DataFrame(subsystems)
# subs_path = ROOT_FOLDER + "\\subsystems.csv"
# subsarray.to_csv(subs_path)

#################### MAIN RESULTS ####################
# Garante tb que normalizas por reacção e não por sample ou por ambos

def preprocess(df,divide=True):
    # global subsystems 
    if divide:
        minind = list(range(0,df.shape[1],2))
        maxind = list(range(1,df.shape[1],2))
    
        min_df = df.iloc[:,minind]
        min_df.columns = list(range(int(df.shape[1]/2)))
        min_df.index = subsystems
        max_df = df.iloc[:,maxind] 
        max_df.columns = list(range(int(df.shape[1]/2)))
        max_df.index = subsystems
        
        return min_df,max_df

    df.index = subsystems
    df.columns = list(range(int(df.shape[1])))
    return df

def process_fva(min_df,max_df,ptr=True):
    max_zero, min_zero = abs(max_df) < 1e-6, abs(min_df) < 1e-6
    max_fwd, min_fwd = max_df > 1e-6, min_df > 1e-6 
    max_rev, min_rev = max_df < -1e-6, min_df < -1e-6  
    blk_df = max_zero & min_zero 
    ess_df = (max_fwd & min_fwd) | (max_rev & min_rev)
    
    allblk = np.sum(blk_df,axis=1) == blk_df.shape[1]
    blk_pt = blk_df.sum().mean()/blk_df.shape[0]
    print("\n","Average inactive reactions:",int(round(blk_df.sum().mean())),
          "(",round(blk_df.sum().mean()/blk_df.shape[0]*100),"%)")
    print("Reactions inactive in all models:",
          round((allblk.sum()*blk_pt)/blk_df.shape[0]*100),"%") #!!
    print("Average Essential reactions:",int(round(ess_df.sum().mean())),
          "(",round(ess_df.sum().mean()/ess_df.shape[0]*100),"%)","\n")

    return ess_df,blk_df  

#more data
md_pfba = pd.read_csv(MORE_MODELS_pfba,header=None,sep=",").iloc[1:,1:]
md_pfbahyp = pd.read_csv(MORE_MODELS_pfba_hyp,header=None,sep=",").iloc[1:,1:]

mdgbm_pfba_df,mdhb_pfba_df = preprocess(md_pfba,False).iloc[:,:2],preprocess(md_pfba,False).iloc[:,2:]
mdgbm_pfbahyp_df,mdhb_pfbahyp_df = preprocess(md_pfbahyp,False).iloc[:,:2],preprocess(md_pfbahyp,False).iloc[:,2:]

test=mdgbm_pfba_df==mdgbm_pfbahyp_df
print(round(mdgbm_pfba_df.shape[0]-test.sum().mean()),
      round((mdgbm_pfba_df.shape[0]-test.sum().mean())/mdgbm_pfba_df.shape[0]*100),"%","(AE GBM)")
test=mdhb_pfba_df==mdhb_pfbahyp_df
print(round(mdhb_pfbahyp_df.shape[0]-test.sum().mean()),
      round((mdhb_pfbahyp_df.shape[0]-test.sum().mean())/mdhb_pfbahyp_df.shape[0]*100),"%","(AST)")

print("Average AE GBM Biomass:", round(mdgbm_pfba_df.iloc[5440,:].mean(),2))
print("Average AE GBM HYP Biomass:",round(mdgbm_pfbahyp_df.iloc[5440,:].mean(),2))
print("Average AST Biomass:",round(mdhb_pfba_df.iloc[5440,:].mean(),2))
print("Average AST HYP Biomass:",round(mdhb_pfbahyp_df.iloc[5440,:].mean(),2),end="\n\n")

print("Average Lactate Drain AE GBM:",
      round(mdgbm_pfba_df.iloc[reaction_ids.index("LDH_L"),:].mean(),2))
print("Average Lactate Drain AE HYP:",
      round(mdgbm_pfbahyp_df.iloc[reaction_ids.index("LDH_L"),:].mean(),2))
print("Average Lactate Drain AST:",
      round(mdhb_pfba_df.iloc[reaction_ids.index("LDH_L"),:].mean(),2))
print("Average Lactate Drain AST HYP:",
      round(mdhb_pfbahyp_df.iloc[reaction_ids.index("LDH_L"),:].mean(),2))

#pyruvate dehydrogenase - null
print("Average PDH AE GBM:",
      round(mdgbm_pfba_df.iloc[reaction_ids.index("PDHm"),:].mean(),2))
print("Average PDH AE GBM HYP:",
      round(mdgbm_pfbahyp_df.iloc[reaction_ids.index("PDHm"),:].mean(),2))
print("Average PDH AST:",
      round(mdhb_pfba_df.iloc[reaction_ids.index("PDHm"),:].mean(),2))
print("Average PDH AST HYP:",
      round(mdhb_pfbahyp_df.iloc[reaction_ids.index("PDHm"),:].mean(),2))

#more data
mdgbm_pfba_abs = pd.DataFrame(mdgbm_pfba_df.abs(),index=subsystems)
mdgbm_pfbahyp_abs = pd.DataFrame(mdgbm_pfbahyp_df.abs(),index=subsystems)
mdhb_pfba_abs = pd.DataFrame(mdhb_pfba_df.abs(),index=subsystems)
mdhb_pfbahyp_abs = pd.DataFrame(mdhb_pfbahyp_df.abs(),index=subsystems)

mdgbm_pfba_gp = mdgbm_pfba_abs.groupby(level=0).sum()
mdgbm_pfbahyp_gp = mdgbm_pfbahyp_abs.groupby(level=0).sum()
mdhb_pfba_gp = mdhb_pfba_abs.groupby(level=0).sum()
mdhb_pfbahyp_gp = mdhb_pfbahyp_abs.groupby(level=0).sum()

#more data
md_ros = [mdgbm_pfba_gp.loc["ROS detoxification",:].mean()/100,
        mdgbm_pfbahyp_gp.loc["ROS detoxification",:].mean()/100,
        mdhb_pfba_gp.loc["ROS detoxification",:].mean()/100,
        mdhb_pfbahyp_gp.loc["ROS detoxification",:].mean()/100]
md_fas = [mdgbm_pfba_gp.loc["Fatty acid synthesis",:].mean()/100,
        mdgbm_pfbahyp_gp.loc["Fatty acid synthesis",:].mean()/100,
        mdhb_pfba_gp.loc["Fatty acid synthesis",:].mean()/100,
        mdhb_pfbahyp_gp.loc["Fatty acid synthesis",:].mean()/100]
md_glyc = [mdgbm_pfba_gp.loc["Glycolysis/gluconeogenesis",:].mean()/100,
        mdgbm_pfbahyp_gp.loc["Glycolysis/gluconeogenesis",:].mean()/100,
        mdhb_pfba_gp.loc["Glycolysis/gluconeogenesis",:].mean()/100,
        mdhb_pfbahyp_gp.loc["Glycolysis/gluconeogenesis",:].mean()/100]
md_tca = [mdgbm_pfba_gp.loc["Citric acid cycle",:].mean()/100,
        mdgbm_pfbahyp_gp.loc["Citric acid cycle",:].mean()/100,
        mdhb_pfba_gp.loc["Citric acid cycle",:].mean()/100,
        mdhb_pfbahyp_gp.loc["Citric acid cycle",:].mean()/100]
md_oxpp = [mdgbm_pfba_gp.loc["Oxidative phosphorylation",:].mean()/100,
        mdgbm_pfbahyp_gp.loc["Oxidative phosphorylation",:].mean()/100,
        mdhb_pfba_gp.loc["Oxidative phosphorylation",:].mean()/100,
        mdhb_pfbahyp_gp.loc["Oxidative phosphorylation",:].mean()/100]
md_ppp = [mdgbm_pfba_gp.loc["Pentose phosphate pathway",:].mean()/100,
        mdgbm_pfbahyp_gp.loc["Pentose phosphate pathway",:].mean()/100,
        mdhb_pfba_gp.loc["Pentose phosphate pathway",:].mean()/100,
        mdhb_pfbahyp_gp.loc["Pentose phosphate pathway",:].mean()/100]

# Average activity barplot
fig1, ax1 = plt.subplots(2,3, figsize = (10,7),sharey=True)
ax1[0,0].set_title('ROS')
ax1[0,1].set_title('FAS')
ax1[0,2].set_title('GLYC')
ax1[1,0].set_title('TCA')
ax1[1,1].set_title('OXPP')
ax1[1,2].set_title('PPP')
ax1[0,0].set_ylim(0,80) 
ax1[1,0].set_ylim(0,80) 
plt.subplots_adjust(hspace =0.275)

ax1[1,0].set_xlabel("Model") 
ax1[1,1].set_xlabel("Model") 
ax1[1,2].set_xlabel("Model") 
s
ax1[0,0].set_ylabel("Average Absolute Sum (Hundreds)")
ax1[1,0].set_ylabel("Average Absolute Sum (Hundreds)")

labels=["GBM","GBM HYP","AST","AST HYP"]
colors=["lightsteelblue","cornflowerblue","gold","goldenrod"]
ax1[0,0].bar(labels,md_ros,color=colors)
ax1[0,1].bar(labels,md_fas,color=colors)
ax1[0,2].bar(labels,md_glyc,color=colors)
ax1[1,0].bar(labels,md_tca,color=colors)
ax1[1,1].bar(labels,md_oxpp,color=colors)
ax1[1,2].bar(labels,md_ppp,color=colors)


########## FVA ##########
md_fva = pd.read_csv(MORE_MODELS_FVA,header=None,sep=",").iloc[1:,1:]
md_fvahyp = pd.read_csv(MORE_MODELS_FVA_HYP,header=None,sep=",").iloc[1:,1:]
min_md,max_md = preprocess(md_fva)
min_mdhyp,max_mdhyp = preprocess(md_fvahyp)

# AE GBM
ess_gbm_md,blk_gbm_md  = process_fva(min_md.iloc[:,:2],max_md.iloc[:,:2])
ess_gbmmd_gp = ess_gbm_md.groupby(level=0).sum()
ess_gbmmd_gp2 = np.sum(ess_gbmmd_gp,axis=1).sort_values(ascending=False)
print(ess_gbmmd_gp2)

#AST
ess_ast,blk_ast  = process_fva(min_md.iloc[:,2:],max_md.iloc[:,2:])
ess_ast_gp = ess_ast.groupby(level=0).sum()
ess_ast_gp2 = np.sum(ess_ast_gp,axis=1).sort_values(ascending=False)
print(ess_ast_gp2)

