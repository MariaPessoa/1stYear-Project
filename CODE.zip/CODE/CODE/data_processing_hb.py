# -*- coding: utf-8 -*-
"""
Created on Wed May  6 15:26:52 2020

@author: liamo
"""
import csv
import pandas as pd
import numpy as np

ROOT_FOLDER = "C:\\Users\\liamo\\Documents\\BIOINF\\PROJ\\files\\"  
GTEX_DATA_PATH = ROOT_FOLDER + "GTEx\\GTEx_Analysis_2017-06-05_v8_RNASeQCv1.1.9_gene_median_tpm.gct"
IDS_PATH = ROOT_FOLDER + "gene_ids_edit.csv"
OUT_ALL_PATH = ROOT_FOLDER + "GTEx\\gtex_log2_all_tissue_CLEAN.csv"

id_mat = np.array(pd.read_csv(IDS_PATH,header=0,sep=";")) #(41818, 10)

dataread = pd.read_csv(GTEX_DATA_PATH,header=2,sep="\t")
tissues = list(dataread.columns.values) 
print(tissues[9:22]) #Brain 9-21 inclusive
data_mat = np.array(dataread)
dheader = list(data_mat[:,0]) #ensembl ids
numrow, numcol = data_mat.shape #(56200, 56)

to_delete = []
reads_header = []
means = []

#convert ensembl ids to entrez  
for h in range(len(dheader)): 
    rowid = data_mat[h,0].split(".")[0]
    if rowid in id_mat[:,4]: #Ensembl Ids
        rowindex = list(np.where(id_mat[:,4] == rowid)[0])
        if len(rowindex) > 0 and len(str(id_mat[int(rowindex[0]),3]).split(".")[0]) > 0:
            if str(id_mat[int(rowindex[0]),3]).split(".")[0] not in reads_header:
                #remove extra from "EntrezId.extra"
                reads_header.append(str(id_mat[int(rowindex[0]),3]).split(".")[0])
            else: to_delete.append(h)
        else: to_delete.append(h)
    else: to_delete.append(h) 

print(len(reads_header),len(set(reads_header))) #checking for repeats  
print("Kept id %:",round((len(dheader)-len(to_delete))/len(dheader)*100))

for r in range(numrow):  #using other tissues as threshold
    if r not in to_delete: 
        if (sum(data_mat[r,2:]) > 0): 
            means.append(sum(data_mat[r,2:])/(numcol-2))    
        else: means.append(0) #unexpressed genes

data_slim = np.delete(data_mat,to_delete,0) #delete rows without EntrezIds    
# del data_mat #save memory
numrow, numcol = data_slim.shape
# reads = []

#all brain tissue
for r in range(numrow): 
    for t in range(2,numcol):
        if means[r] > 0: #normalization
            quantiles = list(np.quantile(data_slim[r,2:],[0.25,0.75]))
            if quantiles[0] > 0 and quantiles[1] > 0:
                if means[r] <= quantiles[0]: #quantile 25
                    # for b in range(9,22):
                    data_slim[r,t] = 5*np.log2(1+(data_slim[r,t]/quantiles[0]))
                elif means[r] >= quantiles[1]: #quantile 75
                    # for b in range(9,22):
                    data_slim[r,t] = 5*np.log2(1+(data_slim[r,t]/quantiles[1]))
                else:
                    # for b in range(9,22): #use mean
                    data_slim[r,t] = 5*np.log2(1+(data_slim[r,t]/means[r]))
            else: data_slim[r,2:] = 0
        else: data_slim[r,2:] = 0
print("Finished processing reads")

# Adding index / model id col
samples = np.array(tissues[1:]).reshape(len(tissues)-1,1)
samples[0,0] = "Tissues"
reads_header = np.array(reads_header).reshape(len(reads_header),1)
all_brain = np.concatenate((reads_header,data_slim[:,2:]),axis=1)
all_brain = all_brain.transpose()
all_brain = np.concatenate((samples,all_brain),axis=1)

with open(OUT_ALL_PATH,"w") as outfile:
    writer = csv.writer(outfile,delimiter=",")
    #brain tissue rows x gene cols
    for r in range(all_brain.shape[0]): writer.writerow(all_brain[r,:])

ht = pd.read_csv(OUT_ALL_PATH,header=0).iloc[:,1]
unexp = np.where(ht.sum()==0)[0]
print("Unexpressed %:",round(len(unexp)/len(dheader)*100))

########## SAME THRESHOLD EXTRA DATA ########## 
MORE_DATA_PATH = ROOT_FOLDER + "GTEx\\NormGeneExp_Samples.tab"
moredata = pd.read_csv(MORE_DATA_PATH,header=0,sep="\t")

#filter genes without Entrez ids
notNan = np.where(moredata["Entrez"].notnull()==True)[0]
moredata2 = moredata.iloc[notNan,:]
#filter repeat Entrez ids
moredata2 = moredata2.drop_duplicates(subset="Entrez")
#filter non relevant data columns
moredata3 = moredata2.iloc[:,np.array([3,4,-3,-2,-1])]

mdmeans = list(np.mean(moredata3,axis=1)) #no 0s
quantiles = moredata3.quantile(q=[0.25,0.75],axis=1)
q25 = list(quantiles.iloc[0,:])
q75 = list(quantiles.iloc[1,:])
moredata_cl = np.zeros((moredata3.shape[0],moredata3.shape[1]))

for row in range(moredata3.shape[0]):
    if mdmeans[row] < q25[row]:
        moredata_cl[row,:] = 5*np.log2(1+(moredata3.iloc[row,:]/q25[row]))
    elif mdmeans[row] > q75[row]: 
        moredata_cl[row,:] = 5*np.log2(1+(moredata3.iloc[row,:]/q75[row]))
    else:
        moredata_cl[row,:] = 5*np.log2(1+(moredata3.iloc[row,:]/mdmeans[row]))

moredata_cl = pd.DataFrame(moredata_cl,index=moredata2.index)
#remove version from ids
mdheader = pd.DataFrame([str(int(x)) for x in list(moredata2["Entrez"])],
             index=moredata2.index)

#transpose for troppo format
moredata_cl2 = pd.concat((mdheader,moredata_cl),axis=1).transpose()
#add index column for troppo format
samplerow = pd.DataFrame(["Entrez"]+list(moredata3.columns),index=moredata_cl2.index)
moredata_final = pd.concat((samplerow,moredata_cl2),axis=1)

MORE_DATA_OUT = ROOT_FOLDER + "GTEx\\NormGeneExp_Samples_log2clean.csv"
moredata_final.to_csv(MORE_DATA_OUT,index=False,header=False)
