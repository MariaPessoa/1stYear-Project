# -*- coding: utf-8 -*-
"""
Created on Fri Jun 12 17:52:28 2020

@author: liamo
"""
# import cobra
from cobra.io import read_sbml_model #, load_matlab_model 
from cobra.flux_analysis import find_essential_reactions,flux_variability_analysis
from cobra.flux_analysis import pfba
import pandas as pd
import numpy as np
# import csv
## PATHS ##
ROOT_FOLDER = "/home/mpessoa/LINUX/"  
MODEL_PATH = ROOT_FOLDER + 'Recon3D_301_ct.xml' 

GBM_PATH = ROOT_FOLDER + "results/" + "r3d_log2_gbm_fastcore.csv"
OUT_GBM_PATH = ROOT_FOLDER + "results/" + "gbm_fva.csv"
OUT_GBM_HYP_PATH = ROOT_FOLDER + "results/" + "gbm_fva_hypoxia.csv"
OUT_GBM_pFBA_PATH = ROOT_FOLDER + "results/" + "gbm_pfba.csv"
OUT_GBM_pFBA_HYP_PATH = ROOT_FOLDER + "results/" + "gbm_pfba_hypoxia.csv"
# OUT_GBM_fba_PATH = ROOT_FOLDER + "results/" + "gbm_fba_fluxes.csv"
# OUT_GBM_fba_HYP_PATH = ROOT_FOLDER + "results/" + "gbm_hypoxia_fluxes.csv"

HB_PATH = ROOT_FOLDER + "results/" + "r3d_log2_hb_fastcore.csv"
OUT_HB_PATH = ROOT_FOLDER + "results/" + "hb_fva_new.csv"
OUT_HB_HYP_PATH = ROOT_FOLDER + "results/" + "hb_fva_hypoxia_new.csv"
OUT_HB_pFBA_PATH = ROOT_FOLDER + "results/" + "hb_pfba_new.csv"
OUT_HB_pFBA_HYP_PATH = ROOT_FOLDER + "results/" + "hb_pfba_hypoxia_new.csv"
# OUT_HB_fba_PATH = ROOT_FOLDER + "results/" + "hb_fba_fluxes.csv"
# OUT_HB_fba_HYP_PATH = ROOT_FOLDER + "results/" + "hb_hypoxia_fluxes.csv"

## MODELS ##
gbmread = pd.read_csv(GBM_PATH,header=0,sep=",") 
gbmheader = list(gbmread.columns.values)[2:]
gbm_mat = np.array(gbmread)[:,2:]

hbread = pd.read_csv(HB_PATH,header=0,sep=",") 
hbheader = list(hbread.columns.values)[2:]
hb_mat = np.array(hbread)[:,2:]

model = read_sbml_model(MODEL_PATH) 
model.objective = "biomass_reaction"
reactions = list(model.reactions) 
essential = list(find_essential_reactions(model,processes=2)) 
print("Essential Consistent:",len(essential)) #3
essential_ids = []
for i in range(len(essential)): essential_ids.append(essential[i].id)
unfeasible = np.array([-1]*len(reactions)).reshape(len(reactions),)

gbm_fva_df = np.zeros((len(reactions),gbm_mat.shape[0]*2))
gbm_fva_hypoxia_df = np.zeros((len(reactions),gbm_mat.shape[0]*2))
hb_fva_df = np.zeros((len(reactions),hb_mat.shape[0]*2))
hb_fva_hypoxia_df = np.zeros((len(reactions),hb_mat.shape[0]*2))

gbm_pfba_df = np.zeros((len(reactions),gbm_mat.shape[0]))
gbm_pfba_hypoxia_df = np.zeros((len(reactions),gbm_mat.shape[0]))
hb_pfba_df = np.zeros((len(reactions),hb_mat.shape[0]))
hb_pfba_hypoxia_df = np.zeros((len(reactions),hb_mat.shape[0]))

## ANALYSIS ##
for m in range(gbm_mat.shape[0]):
    model_gbm = read_sbml_model(MODEL_PATH) 
    model_gbm.objective = "biomass_reaction" 
    
    for r in range(len(gbmheader)):
        if gbm_mat[m,r] == False and gbmheader[r] not in essential_ids:
            model_gbm.reactions.get_by_id(gbmheader[r]).bounds = (0,0) 
    
    fba_gbm = model_gbm.optimize()
    if fba_gbm.status == "optimal": 
        try:
            gbm_results_pfba = np.array(pfba(model_gbm).fluxes)
            gbm_pfba_df[:,m] = gbm_results_pfba
        except:
            gbm_pfba_df[:,m] = unfeasible
        
        model_gbm.reactions.get_by_id("EX_o2[e]").bounds = (0,1000) 
        try:
            gbm_results_hypoxia_pfba = np.array(pfba(model_gbm).fluxes)
            gbm_pfba_hypoxia_df[:,m] = gbm_results_hypoxia_pfba
        except:
            gbm_pfba_hypoxia_df[:,m] = unfeasible
            
        model_gbm.reactions.get_by_id("EX_o2[e]").bounds = (-1000,1000) 
        try:
            gbm_results_fva = np.array(flux_variability_analysis(model_gbm,fraction_of_optimum=0.1))
        except:
            gbm_results_fva = np.concatenate((unfeasible,unfeasible),axis=1)
            
        model_gbm.reactions.get_by_id("EX_o2[e]").bounds = (0,1000) 
        try:
            gbm_results_hypoxia_fva = np.array(flux_variability_analysis(model_gbm,fraction_of_optimum=0.1))
        except:
            gbm_results_hypoxia_fva = np.concatenate((unfeasible,unfeasible),axis=1)
        
        gbm_fva_df[:,(m*2):(m*2)+2] = gbm_results_fva
        gbm_fva_hypoxia_df[:,(m*2):(m*2)+2] = gbm_results_hypoxia_fva
    else: 
        gbm_pfba_df[:,m] = unfeasible
        gbm_pfba_hypoxia_df[:,m] = unfeasible
        gbm_fva_df[:,(m*2):(m*2)+2] = np.concatenate((unfeasible,unfeasible),axis=1)
        gbm_fva_hypoxia_df[:,(m*2):(m*2)+2] = np.concatenate((unfeasible,unfeasible),axis=1)


for m in range(hb_mat.shape[0]):
    model_hb = read_sbml_model(MODEL_PATH) 
    model_hb.objective = "biomass_reaction"   #"biomass_maintenance"
    
    for r in range(len(hbheader)):
        if hb_mat[m,r] == False and hbheader[r] not in essential_ids:
            model_hb.reactions.get_by_id(hbheader[r]).bounds = (0,0) 
    
    hb_fba= model_hb.optimize()
    if hb_fba.status == "optimal": 
        try:
            hb_results_pfba = np.array(pfba(model_hb).fluxes)
            hb_pfba_df[:,m] = hb_results_pfba
        except:
            hb_pfba_df[:,m] = unfeasible
        
        model_hb.reactions.get_by_id("EX_o2[e]").bounds = (0,1000) 
        try:
            hb_results_hypoxia_pfba = np.array(pfba(model_hb).fluxes)
            hb_pfba_hypoxia_df[:,m] = hb_results_hypoxia_pfba
        except:
            hb_pfba_hypoxia_df[:,m] = unfeasible
        
        model_hb.reactions.get_by_id("EX_o2[e]").bounds = (-1000,1000) 
        try:
            hb_results_fva = np.array(flux_variability_analysis(model_hb,fraction_of_optimum=0.1))
        except:
            hb_results_fva = np.concatenate((unfeasible,unfeasible),axis=1)
            
        model_hb.reactions.get_by_id("EX_o2[e]").bounds = (0,1000) 
        try:
            hb_results_hypoxia_fva = np.array(flux_variability_analysis(model_hb,fraction_of_optimum=0.1))
        except:
            hb_results_hypoxia_fva = np.concatenate((unfeasible,unfeasible),axis=1)
        
        hb_fva_df[:,(m*2):(m*2)+2] = hb_results_fva
        hb_fva_hypoxia_df[:,(m*2):(m*2)+2] = hb_results_hypoxia_fva
    else: 
        hb_pfba_df[:,m] = unfeasible
        hb_pfba_hypoxia_df[:,m] = unfeasible
        hb_fva_df[:,(m*2):(m*2)+2] = np.concatenate((unfeasible,unfeasible),axis=1)
        hb_fva_hypoxia_df[:,(m*2):(m*2)+2] = np.concatenate((unfeasible,unfeasible),axis=1)

### OUTPUT ###
gbm_fva_df = pd.DataFrame(gbm_fva_df)
gbm_fva_hypoxia_df = pd.DataFrame(gbm_fva_hypoxia_df)
hb_fva_df = pd.DataFrame(hb_fva_df)
hb_fva_hypoxia_df = pd.DataFrame(hb_fva_hypoxia_df)

gbm_fva_df.to_csv(OUT_GBM_PATH)
gbm_fva_hypoxia_df.to_csv(OUT_GBM_HYP_PATH)
hb_fva_df.to_csv(OUT_HB_PATH)
hb_fva_hypoxia_df.to_csv(OUT_HB_HYP_PATH)
###
gbm_pfba_df = pd.DataFrame(gbm_pfba_df)
gbm_pfba_hypoxia_df = pd.DataFrame(gbm_pfba_hypoxia_df)
hb_pfba_df = pd.DataFrame(hb_pfba_df)
hb_pfba_hypoxia_df = pd.DataFrame(hb_pfba_hypoxia_df)

gbm_pfba_df.to_csv(OUT_GBM_pFBA_PATH)
gbm_pfba_hypoxia_df.to_csv(OUT_GBM_pFBA_HYP_PATH)
hb_pfba_df.to_csv(OUT_HB_pFBA_PATH)
hb_pfba_hypoxia_df.to_csv(OUT_HB_pFBA_HYP_PATH)

