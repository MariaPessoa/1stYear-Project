# -*- coding: utf-8 -*-
"""
Created on Fri May  8 21:24:58 2020

@author: liamo
"""
from cobra.io import read_sbml_model, load_matlab_model
# from cobra.flux_analysis import find_essential_reactions 
import pandas as pd
import numpy as np
# import json, csv
import matplotlib.pyplot as plt
    
# if __name__ == '__main__':
ROOT_FOLDER = "C:\\Users\\liamo\\Documents\\BIOINF\\PROJ\\files"  
GBM_PATH = ROOT_FOLDER + "\\results\\" + "r3d_log2_gbm_fastcore.csv"
HB_PATH = ROOT_FOLDER + "\\results\\" + "r3d_log2_hb_fastcore.csv"
GTEX_DATA_PATH = ROOT_FOLDER + "\\GTEx\\GTEx_Analysis_2017-06-05_v8_RNASeQCv1.1.9_gene_median_tpm.gct"
MODEL_PATH = ROOT_FOLDER + '\\Recon3D_301_ct.xml'  
MODEL_MAT_PATH = ROOT_FOLDER + '\\Recon3D.mat'

GBM_FVA_PATH = ROOT_FOLDER + "\\results\\" + "gbm_fva.csv"
GBM_FVA_HYP_PATH = ROOT_FOLDER + "\\results\\" + "gbm_fva_hypoxia.csv"
HB_FVA_PATH = ROOT_FOLDER + "\\results\\" + "hb_fva.csv"
HB_FVA_HYP_PATH = ROOT_FOLDER + "\\results\\" + "hb_fva_hypoxia.csv"

GBM_pFBA_PATH = ROOT_FOLDER + "\\results\\" + "gbm_pfba.csv"
GBM_pFBA_HYP_PATH = ROOT_FOLDER + "\\results\\" + "gbm_pfba_hypoxia.csv"
HB_pFBA_PATH = ROOT_FOLDER + "\\results\\" + "hb_pfba.csv"
HB_pFBA_HYP_PATH = ROOT_FOLDER + "\\results\\" + "hb_pfba_hypoxia.csv"

dataread = pd.read_csv(GTEX_DATA_PATH,header=2,sep="\t")
print(list(dataread.columns.values)[9:22])

gbmread = pd.read_csv(GBM_PATH,header=0,sep=",") 
gbmheader = list(gbmread.columns.values)[2:]
gbm_mat = np.array(gbmread)[:,2:]
# print(gbm_mat.shape) #(174, 11961)

hbread = pd.read_csv(HB_PATH,header=0,sep=",") 
hbheader = list(hbread.columns.values)[2:]
hb_mat = np.array(hbread)[:,2:] #CHECK COMMON GENES?
# print(hb_mat.shape) #(54, 11961), #Brain 7-20 inclusive

#checking for reconstruction issues, ex: all reactions set to False
#counts True
print(np.sum(np.any(hb_mat,axis=0)),
      round(np.sum(np.any(hb_mat,axis=0))/hb_mat.shape[1]*100),"%")
print(np.sum(np.any(gbm_mat,axis=0)),
      round(np.sum(np.any(gbm_mat,axis=0))/gbm_mat.shape[1]*100),"%")
#check if biomass_reaction set to False - counts False / should be 0
print(gbm_mat.shape[0]-np.sum(gbm_mat[:,5440]))
print(hb_mat.shape[0]-np.sum(hb_mat[:,5440]))
# print(mdread.shape[0]-np.sum(mdread.iloc[:,5440]))

print("Average GBM reaction count:",round(np.mean(np.sum(gbm_mat,axis=1))),"\n",
      "HT Recon3D total reaction %:",round(np.mean(np.sum(gbm_mat,axis=1))/11961*100))
print("Average HT reaction count:",round(np.mean(np.sum(hb_mat,axis=1))),"\n",
      "HT Recon3D total reaction %:",round(np.mean(np.sum(hb_mat,axis=1))/11961*100))
print("Average HB reaction count:",
      round(np.mean(np.sum(hb_mat[9:22,:],axis=1))),"\n",
      "HB Recon3D total reaction %:",round(np.mean(np.sum(hb_mat[9:22,:],axis=1))/11961*100)) 

################## RECON3D #####################
model = read_sbml_model(MODEL_PATH) 
model.objective = "biomass_reaction" #biomass_maintenance

# PATHWAYs / subsystems (.mat model)
model_mat = load_matlab_model(MODEL_MAT_PATH)
reactions = list(model.reactions) #sbml
sinks = list(model.sinks) #sbml ct 94 vs mat 92
sinks_indexs = []
for s in sinks: sinks_indexs.append(reactions.index(s))
reaction_ids = []
mat_ids = []
for r in list(model_mat.reactions): mat_ids.append(r.id)
subsystems = [] 
for r in reactions:
    reaction_ids.append(r.id)
    if r.id in mat_ids:
        subsystems.append(model_mat.reactions.get_by_id(r.id).subsystem)
    else: subsystems.append("Unknown") #3714
# subsarray = pd.DataFrame(subsystems)
# subs_path = ROOT_FOLDER + "\\subsystems.csv"
# subsarray.to_csv(subs_path)

model_fba = model.optimize()
model.reactions.get_by_id("EX_o2[e]").bounds = (0,0) #o2[e] <=>
modelhyp_fba = model.optimize()
model.reactions.get_by_id("EX_o2[e]").bounds = (-1000,1000)

print(model_fba.status,model_fba.objective_value) 
print(modelhyp_fba.status,modelhyp_fba.objective_value)

#################### MAIN RESULTS ####################
# Garante tb que normalizas por reacção e não por sample ou por ambos

def preprocess(df,divide=True):
    # global subsystems 
    if divide:
        minind = list(range(0,df.shape[1],2))
        maxind = list(range(1,df.shape[1],2))
    
        min_df = df.iloc[:,minind]
        min_df.columns = list(range(int(df.shape[1]/2)))
        min_df.index = subsystems
        max_df = df.iloc[:,maxind] 
        max_df.columns = list(range(int(df.shape[1]/2)))
        max_df.index = subsystems
        
        return min_df,max_df

    df.index = subsystems
    df.columns = list(range(int(df.shape[1])))
    return df

def process_fva(min_df,max_df,ptr=True):
    max_zero, min_zero = abs(max_df) < 1e-6, abs(min_df) < 1e-6
    max_fwd, min_fwd = max_df > 1e-6, min_df > 1e-6 
    max_rev, min_rev = max_df < -1e-6, min_df < -1e-6  
    blk_df = max_zero & min_zero 
    ess_df = (max_fwd & min_fwd) | (max_rev & min_rev)
    
    allblk = np.sum(blk_df,axis=1) == blk_df.shape[1]
    blk_pt = blk_df.sum().mean()/blk_df.shape[0]
    print("\n","Average inactive reactions:",int(round(blk_df.sum().mean())),
          "(",round(blk_df.sum().mean()/blk_df.shape[0]*100),"%)")
    print("Reactions inactive in all models:",
          round((allblk.sum()*blk_pt)/blk_df.shape[0]*100),"%") #!!
    print("Average Essential reactions:",int(round(ess_df.sum().mean())),
          "(",round(ess_df.sum().mean()/ess_df.shape[0]*100),"%)","\n")

    return ess_df,blk_df  

########## pFBA ##########
gbmpfba = pd.read_csv(GBM_pFBA_PATH,header=0,sep=",").iloc[:,1:]
gbmpfbahyp = pd.read_csv(GBM_pFBA_HYP_PATH,header=0,sep=",").iloc[:,1:]
hbpfba = pd.read_csv(HB_pFBA_PATH,header=0,sep=",").iloc[:,1:]
hbpfbahyp = pd.read_csv(HB_pFBA_HYP_PATH,header=0,sep=",").iloc[:,1:]

#preprocess(df,divide=False) only adds index
gbmpfba_df = preprocess(gbmpfba,False)
gbmpfbahyp_df = preprocess(gbmpfbahyp,False)
hbpfba_df = preprocess(hbpfba,False).iloc[:,9:22] 
hbpfbahyp_df = preprocess(hbpfbahyp,False).iloc[:,9:22] 

#filter low variance GBM models #axis=0 -> column variance
gbmpfba_df2 = gbmpfba_df.drop(
    gbmpfba_df.loc[:,gbmpfba_df.var(axis=0)>=
                      gbmpfba_df.var(axis=0).mean()].columns.values,axis=1)
gbmpfbahyp_df2 = gbmpfbahyp_df.iloc[:,gbmpfba_df2.columns]
print(gbmpfba_df2.shape[1],"vs",gbmpfba_df.shape[1]) #88 vs 174

#biomass_reaction - 5440 - reaction_ids.index("biomass_reaction")
temp = gbmpfba_df2.iloc[5440,:]>1e-6
biomass_filter = np.where(temp==True)[0]
print(len(biomass_filter),"vs",gbmpfba_df2.shape[1]) 
gbmpfba_df2 = gbmpfba_df2.iloc[:,biomass_filter]
gbmpfbahyp_df2 = gbmpfbahyp_df2.iloc[:,biomass_filter]

print("Average GBM Biomass:", round(gbmpfba_df2.iloc[5440,:].mean(),2))
print("Average GBM HYP Biomass:",round(gbmpfbahyp_df2.iloc[5440,:].mean(),2))
print("Average HB Biomass:",round(hbpfba_df.iloc[5440,:].mean(),2))
print("Average HB HYP Biomass:",round(hbpfbahyp_df.iloc[5440,:].mean(),2),end="\n\n")

#smaller than GBM average
ind = hbpfba_df.iloc[5440,np.where(hbpfba_df.iloc[5440,:] < gbmpfba_df2.iloc[5440,:].mean())[0]]
print(ind)
print(dataread.iloc[:,ind.index].columns.values)

print("Average Lactate Drain GBM:",
      round(gbmpfba_df2.iloc[reaction_ids.index("LDH_L"),:].mean(),2))
print("Average Lactate Drain GBM HYP:",
      round(gbmpfbahyp_df2.iloc[reaction_ids.index("LDH_L"),:].mean(),2))
print("Average Lactate Drain HB:",
      round(hbpfba_df.iloc[reaction_ids.index("LDH_L"),:].mean(),2))
print("Average Lactate Drain HB HYP:",
      round(hbpfbahyp_df.iloc[reaction_ids.index("LDH_L"),:].mean(),2))

#pyruvate dehydrogenase
print("Average PDH GBM:",
      round(gbmpfba_df2.iloc[reaction_ids.index("PDHm"),:].mean(),2))
print("Average PDH HYP:",
      round(gbmpfbahyp_df2.iloc[reaction_ids.index("PDHm"),:].mean(),2))
print("Average PDH HB:",
      round(hbpfba_df.iloc[reaction_ids.index("PDHm"),:].mean(),2))
print("Average PDH HYP:",
      round(hbpfbahyp_df.iloc[reaction_ids.index("PDHm"),:].mean(),2))

### Total absolute sum ###
gbmpfba_df2_abs = pd.DataFrame(gbmpfba_df2.abs(),index=subsystems)
gbmpfbahyp_df2_abs = pd.DataFrame(gbmpfbahyp_df2.abs(),index=subsystems)
hbpfba_df_abs = pd.DataFrame(hbpfba_df.abs(),index=subsystems)
hbpfbahyp_df_abs = pd.DataFrame(hbpfbahyp_df.abs(),index=subsystems)

gbmpfba_df2_gp = gbmpfba_df2_abs.groupby(level=0).sum()
gbmpfbahyp_df2_gp = gbmpfbahyp_df2_abs.groupby(level=0).sum()
hbpfba_df_gp = hbpfba_df_abs.groupby(level=0).sum()
hbpfbahyp_df_gp = hbpfbahyp_df_abs.groupby(level=0).sum()

#Nucleotide metabolism, Protein formation null average
print("Average ROS detoxification Activity GBM (Hundreds)):",
      round(gbmpfba_df2_gp.loc["ROS detoxification",:].mean()/100,2))
print("Average ROS detoxification Activity GBM HYP:",
      round(gbmpfbahyp_df2_gp.loc["ROS detoxification",:].mean()/100,2))
print("Average ROS detoxification Activity HB:",
      round(hbpfba_df_gp.loc["ROS detoxification",:].mean()/100,2))
print("Average ROS detoxification Activity HB HYP:",
      round(hbpfbahyp_df_gp.loc["ROS detoxification",:].mean()/100,2))

# print(subsystems.count("Fatty acid synthesis"))
print("Average Fatty acid synthesis Activity GBM (Hundreds):",
      round(gbmpfba_df2_gp.loc["Fatty acid synthesis",:].mean()/100,2))
print("Average Fatty acid synthesis Activity GBM HYP:",
      round(gbmpfbahyp_df2_gp.loc["Fatty acid synthesis",:].mean()/100,2))
print("Average Fatty acid synthesis Activity HB:",
      round(hbpfba_df_gp.loc["Fatty acid synthesis",:].mean()/100,2))
print("Average Fatty acid synthesis Activity HB HYP:",
      round(hbpfbahyp_df_gp.loc["Fatty acid synthesis",:].mean()/100,2))

glyc = [gbmpfba_df2_gp.loc["Glycolysis/gluconeogenesis",:]/100,
        gbmpfbahyp_df2_gp.loc["Glycolysis/gluconeogenesis",:]/100,
        hbpfba_df_gp.loc["Glycolysis/gluconeogenesis",:]/100,
        hbpfbahyp_df_gp.loc["Glycolysis/gluconeogenesis",:]/100]

tca = [gbmpfba_df2_gp.loc["Citric acid cycle",:]/100,
        gbmpfbahyp_df2_gp.loc["Citric acid cycle",:]/100,
        hbpfba_df_gp.loc["Citric acid cycle",:]/100,
        hbpfbahyp_df_gp.loc["Citric acid cycle",:]/100]

oxpp = [gbmpfba_df2_gp.loc["Oxidative phosphorylation",:]/100,
        gbmpfbahyp_df2_gp.loc["Oxidative phosphorylation",:]/100,
        hbpfba_df_gp.loc["Oxidative phosphorylation",:]/100,
        hbpfbahyp_df_gp.loc["Oxidative phosphorylation",:]/100]

ppp = [gbmpfba_df2_gp.loc["Pentose phosphate pathway",:]/100,
        gbmpfbahyp_df2_gp.loc["Pentose phosphate pathway",:]/100,
        hbpfba_df_gp.loc["Pentose phosphate pathway",:]/100,
        hbpfbahyp_df_gp.loc["Pentose phosphate pathway",:]/100]

### GRAPHS ###
# Average activity barplot
fig1, ax1 = plt.subplots(1,4, figsize = (13,5),sharey=True)
ax1[0].set_title('GLYC')
ax1[1].set_title('TCA')
ax1[2].set_title('OXPP')
ax1[3].set_title('PPP')
ax1[0].set_ylim(0,80) 
ax1[0].set_xlabel("Model") 
ax1[1].set_xlabel("Model") 
ax1[2].set_xlabel("Model") 
ax1[3].set_xlabel("Model") 

ax1[0].set_ylabel("Average Absolute Sum (Hundreds)")
labels=["GBM","GBM HYP","HB","HB HYP"]
colors=["lightsteelblue","cornflowerblue","springgreen","mediumseagreen"]
ax1[0].bar(labels,[x.mean() for x in glyc],color=colors)
ax1[1].bar(labels,[x.mean() for x in tca],color=colors)
ax1[2].bar(labels,[x.mean() for x in oxpp],color=colors)
ax1[3].bar(labels,[x.mean() for x in ppp],color=colors)

#GLYC histogram
fig1, ax1 = plt.subplots(2,2, figsize = (10,8.5),sharex='col', sharey='row')
ax1[0,0].set_ylim(0,35) 
ax1[1,0].set_ylim(0,3)
ax1[0,0].set_xlim(0,140)
ax1[1,1].set_xlim(0,140)
plt.subplots_adjust(wspace=0.275)

ax1[1,0].set_xlabel("Absolute Sum (Hundreds)")
ax1[1,1].set_xlabel("Absolute Sum (Hundreds)")
ax1[0,0].set_ylabel("Density")
ax1[1,0].set_ylabel("Density")

ax1[0,0].set_title('GLYC GBM')
ax1[0,0].hist(glyc[0],bins=8,color="lightsteelblue")
glyc[0].plot(kind='kde', ax=ax1[0,0], secondary_y=True)
ax1[0,1].set_title('GLYC GBM HYP')
ax1[0,1].hist(glyc[1],bins=8,color="cornflowerblue")
glyc[1].plot(kind='kde', ax=ax1[0,1], secondary_y=True)
plt.ylabel('Kernel Density Estimation')

ax1[1,0].set_title('GLYC HB')
ax1[1,0].hist(glyc[2],bins=8,color="springgreen")
glyc[2].plot(kind='kde', ax=ax1[1,0], secondary_y=True)
ax1[1,1].set_title('GLYC HB HYP')
ax1[1,1].hist(glyc[3],bins=8,color="mediumseagreen")
glyc[3].plot(kind='kde', ax=ax1[1,1], secondary_y=True)
plt.ylabel('Kernel Density Estimation')

#TCA histogram
fig1, ax1 = plt.subplots(2,2, figsize = (10,8.5),sharex='col', sharey='row')
ax1[0,0].set_ylim(0,50)
ax1[1,0].set_ylim(0,6)
ax1[0,0].set_xlim(0,140)
ax1[1,1].set_xlim(0,140)
plt.subplots_adjust(wspace=0.275)

ax1[1,0].set_xlabel("Absolute Sum (Hundreds)")
ax1[1,1].set_xlabel("Absolute Sum (Hundreds)")
ax1[0,0].set_ylabel("Density")
ax1[1,0].set_ylabel("Density")

ax1[0,0].set_title('TCA GBM')
ax1[0,0].hist(tca[0],bins=8,color="lightsteelblue")
tca[0].plot(kind='kde', ax=ax1[0,0], secondary_y=True)
ax1[0,1].set_title('TCA GBM HYP')
ax1[0,1].hist(tca[1],bins=8,color="cornflowerblue")
tca[1].plot(kind='kde', ax=ax1[0,1], secondary_y=True)
plt.ylabel('Kernel Density Estimation')

ax1[1,0].set_title('TCA HB')
ax1[1,0].hist(tca[2],bins=8,color="springgreen")
tca[2].plot(kind='kde', ax=ax1[1,0], secondary_y=True)
ax1[1,1].set_title('TCA HB HYP')
ax1[1,1].hist(tca[3],bins=8,color="mediumseagreen")
tca[3].plot(kind='kde', ax=ax1[1,1], secondary_y=True)
plt.ylabel('Kernel Density Estimation')

#OXPP histogram
fig1, ax1 = plt.subplots(2,2, figsize = (10,8.5),sharex='col', sharey='row')
ax1[0,0].set_ylim(0,18) 
ax1[1,0].set_ylim(0,6)
ax1[0,0].set_xlim(0,140)
ax1[1,1].set_xlim(0,140)
plt.subplots_adjust(wspace=0.275)

ax1[1,0].set_xlabel("Absolute Sum (Hundreds)")
ax1[1,1].set_xlabel("Absolute Sum (Hundreds)")
ax1[0,0].set_ylabel("Density")
ax1[1,0].set_ylabel("Density")

ax1[0,0].set_title('OXPP GBM')
ax1[0,0].hist(oxpp[0],bins=8,color="lightsteelblue")
oxpp[0].plot(kind='kde', ax=ax1[0,0], secondary_y=True)
ax1[0,1].set_title('OXPP GBM HYP')
ax1[0,1].hist(oxpp[1],bins=8,color="cornflowerblue")
oxpp[1].plot(kind='kde', ax=ax1[0,1], secondary_y=True)
plt.ylabel('Kernel Density Estimation')

ax1[1,0].set_title('OXPP HB')
ax1[1,0].hist(oxpp[2],bins=8,color="springgreen")
oxpp[2].plot(kind='kde', ax=ax1[1,0], secondary_y=True)
ax1[1,1].set_title('OXPP HB HYP')
ax1[1,1].hist(oxpp[3],bins=8,color="mediumseagreen")
oxpp[3].plot(kind='kde', ax=ax1[1,1], secondary_y=True)
plt.ylabel('Kernel Density Estimation')

#PPP histogram
fig1, ax1 = plt.subplots(2,2, figsize = (10,8.5),sharex='col', sharey='row')
ax1[0,0].set_ylim(0,26)
ax1[1,0].set_ylim(0,4)
ax1[0,0].set_xlim(0,140)
ax1[1,1].set_xlim(0,140)
plt.subplots_adjust(wspace=0.275)

ax1[1,0].set_xlabel("Absolute Sum (Hundreds)")
ax1[1,1].set_xlabel("Absolute Sum (Hundreds)")
ax1[0,0].set_ylabel("Density")
ax1[1,0].set_ylabel("Density")

ax1[0,0].set_title('PPP GBM')
ax1[0,0].hist(ppp[0],bins=8,color="lightsteelblue")
ppp[0].plot(kind='kde', ax=ax1[0,0], secondary_y=True)
ax1[0,1].set_title('PPP GBM HYP')
ax1[0,1].hist(ppp[1],bins=8,color="cornflowerblue")
ppp[1].plot(kind='kde', ax=ax1[0,1], secondary_y=True)
plt.ylabel('Kernel Density Estimation')

ax1[1,0].set_title('PPP HB')
ax1[1,0].hist(ppp[2],bins=8,color="springgreen")
ppp[2].plot(kind='kde', ax=ax1[1,0], secondary_y=True)
ax1[1,1].set_title('PPP HB HYP')
ax1[1,1].hist(ppp[3],bins=8,color="mediumseagreen")
ppp[3].plot(kind='kde', ax=ax1[1,1], secondary_y=True)
plt.ylabel('Kernel Density Estimation')

### exporting for pca in R ###
fluxes_pfba = pd.concat([gbmpfba_df2_abs.transpose(),
                        gbmpfbahyp_df2_abs.transpose(),
                        hbpfba_df_abs.transpose(),
                        hbpfbahyp_df_abs.transpose()],axis=0,
                        keys=["GBM","GBM_HYP","HB","HB_HYP"])
OUT_pFBA = ROOT_FOLDER + "\\results\\" + "pfba_fluxes_pca.csv"
fluxes_pfba.to_csv(OUT_pFBA,index=True)

#ttest / pathway entre modelos
########## FVA ##########
gbmfva = pd.read_csv(GBM_FVA_PATH,header=0,sep=",").iloc[:,1:]
gbmfvahyp = pd.read_csv(GBM_FVA_HYP_PATH,header=0,sep=",").iloc[:,1:]
hbfva = pd.read_csv(HB_FVA_PATH,header=0,sep=",").iloc[:,1:]
hbfvahyp = pd.read_csv(HB_FVA_HYP_PATH,header=0,sep=",").iloc[:,1:]

min_gbm,max_gbm = preprocess(gbmfva)
min_gbm,max_gbm = min_gbm.iloc[:,gbmpfba_df2.columns],max_gbm.iloc[:,gbmpfba_df2.columns]
min_gbm_hyp,max_gbm_hyp = preprocess(gbmfvahyp)
min_gbm_hyp,max_gbm_hyp = min_gbm_hyp.iloc[:,gbmpfba_df2.columns],max_gbm_hyp.iloc[:,gbmpfba_df2.columns]

min_hb,max_hb = preprocess(hbfva)
min_hb,max_hb = min_hb.iloc[:,9:22],max_hb.iloc[:,9:22]
min_hb_hyp,max_hb_hyp = preprocess(hbfvahyp)
min_hb_hyp,max_hb_hyp = min_hb_hyp.iloc[:,9:22],max_hb_hyp.iloc[:,9:22]

#GBM    
ess_gbm,blk_gbm  = process_fva(min_gbm,max_gbm)
ess_gbm_gp = ess_gbm.groupby(level=0).sum()
ess_gbm_gp2 = np.sum(ess_gbm_gp,axis=1).sort_values(ascending=False)
print(ess_gbm_gp2)

blk_gbm_gp = blk_gbm.groupby(level=0).sum()
blk_gbm_gp2 = np.sum(blk_gbm_gp,axis=1).sort_values(ascending=False)
print(blk_gbm_gp2)

#HB
ess_hb,blk_hb = process_fva(min_hb,max_hb)
ess_hb_gp = ess_hb.groupby(level=0).sum()
ess_hb_gp2 = np.sum(ess_hb_gp,axis=1).sort_values(ascending=False)
print(ess_hb_gp2)

blk_hb_gp = blk_hb.groupby(level=0).sum()
blk_hb_gp2 = np.sum(blk_hb_gp,axis=1).sort_values(ascending=False)
print(blk_hb_gp2)

