# -*- coding: utf-8 -*-
"""
Created on Mon Jul 13 12:22:54 2020

@author: liamo
"""
from cobra.io import read_sbml_model, load_matlab_model
from cobra.flux_analysis import find_essential_reactions 
import pandas as pd
import numpy as np
import json, csv
import matplotlib.pyplot as plt

# if __name__ == '__main__':
    
ROOT_FOLDER = "C:\\Users\\liamo\\Documents\\BIOINF\\PROJ\\files"  
TASKS_PATH = ROOT_FOLDER + "\\nl2019_tasks_r3d_compact.json"
GBM_TASKS_PATH = ROOT_FOLDER + "\\results\\" + "r3d_log2_gbm_task_results.json"
HB_PATH = ROOT_FOLDER + "\\results\\" + "r3d_log2_hb_fastcore.csv"
HB_TASKS_PATH = ROOT_FOLDER + "\\results\\" + "r3d_log2_hb_task_results.json"
MORE_MODELS_TASKS = ROOT_FOLDER + "\\results\\" + "r3d_log2_MOREDATA_task_results.json"
META_GBM_PATH = ROOT_FOLDER + "\\metadata.csv"

### RECON3D ###
MODEL_PATH = ROOT_FOLDER + '\\Recon3D_301_ct.xml'  
MODEL_MAT_PATH = ROOT_FOLDER + '\\Recon3D.mat'
model = read_sbml_model(MODEL_PATH) 
model.objective = "biomass_reaction" #biomass_maintenance

# PATHWAYs / subsystems (.mat model)
model_mat = load_matlab_model(MODEL_MAT_PATH)
reactions = list(model.reactions) #sbml
# sinks = list(model.sinks) #sbml ct 94 vs mat 92
# sinks_indexs = []
# for s in sinks: sinks_indexs.append(reactions.index(s))
reaction_ids = []
mat_ids = []
for r in list(model_mat.reactions): mat_ids.append(r.id)
subsystems = [] 
for r in reactions:
    reaction_ids.append(r.id)
    if r.id in mat_ids:
        subsystems.append(model_mat.reactions.get_by_id(r.id).subsystem)
    else: subsystems.append("Unknown")

def preprocess(df,divide=True):
    # global subsystems 
    if divide:
        minind = list(range(0,df.shape[1],2))
        maxind = list(range(1,df.shape[1],2))
    
        min_df = df.iloc[:,minind]
        min_df.columns = list(range(int(df.shape[1]/2)))
        min_df.index = subsystems
        max_df = df.iloc[:,maxind] 
        max_df.columns = list(range(int(df.shape[1]/2)))
        max_df.index = subsystems
        
        return min_df,max_df
    
    df.index = subsystems
    df.columns = list(range(int(df.shape[1])))
    return df

### pFBA ###
GBM_pFBA_PATH = ROOT_FOLDER + "\\results\\" + "gbm_pfba.csv"
# GBM_pFBA_HYP_PATH = ROOT_FOLDER + "\\results\\" + "gbm_pfba_hypoxia.csv"
subs_path = ROOT_FOLDER + "\\subsystems.csv"
subsystems = pd.read_csv(subs_path).iloc[:,1]
subsystems = list(subsystems)

gbmpfba = pd.read_csv(GBM_pFBA_PATH,header=0,sep=",").iloc[:,1:]
#preprocess(df,divide=False) only adds index
gbmpfba_df = preprocess(gbmpfba,False)

#filter low variance GBM models #axis=0 -> column variance
gbmpfba_df2 = gbmpfba_df.drop(
    gbmpfba_df.loc[:,gbmpfba_df.var(axis=0)>=
                      gbmpfba_df.var(axis=0).mean()].columns.values,axis=1)

#biomass_reaction - 5440 - reaction_ids.index("biomass_reaction")
temp = gbmpfba_df2.iloc[5440,:]>1e-6
biomass_filter = np.where(temp==True)[0]
gbmpfba_df2 = gbmpfba_df2.iloc[:,biomass_filter]

###### TASK ANALYSIS ######
tasks = json.load(open(TASKS_PATH)) #list of dicts
tasks_subsys = []
for t in tasks: tasks_subsys.append(t["annotations"]["subsystem"])
task_count = {}
for t in tasks_subsys: task_count[t] = tasks_subsys.count(t)
task_ct_np = np.array(list(task_count.values()))

# list of lists: 174 x 2 x 210, json[0 or 1]: list, dict w 210 keys 
gbm_tasks = json.load(open(GBM_TASKS_PATH)) 
# list of lists: 54 x 2 x 210
hb_tasks = json.load(open(HB_TASKS_PATH))
# list of lists: 5 x 2 x 210
md_tasks = json.load(open(MORE_MODELS_TASKS))

gbm_tasks_df = pd.DataFrame(np.zeros((210,len(gbm_tasks))),index=tasks_subsys)
hb_tasks_df = pd.DataFrame(np.zeros((210,len(hb_tasks))),index=tasks_subsys)
md_tasks_df = pd.DataFrame(np.zeros((210,len(md_tasks))),index=tasks_subsys)

#sorted by # of passed tasks
for m in range(len(gbm_tasks)):
    for k,v in gbm_tasks[m][1].items():
        if True in v: gbm_tasks_df.iloc[int(k)-1,m] += 1
#top ten (model row, tasks passed)
# print(sorted(gbm_tasks_total.items(), key=lambda kv: kv[1],reverse=True)[:10]) 
        
for m in range(len(hb_tasks)):
    # if m >= 9 and m <= 21: #only brain models
    for k,v in hb_tasks[m][1].items():
        if True in v: hb_tasks_df.iloc[int(k)-1,m] += 1
# print(sorted(hb_tasks_total.items(), key=lambda kv: kv[1],reverse=True)[:10]) 

for m in range(len(md_tasks)):
    for k,v in md_tasks[m][1].items():
        if True in v: md_tasks_df.iloc[int(k)-1,m] += 1

### by pathway ###
gbm_tasks_df2 = gbm_tasks_df.iloc[:,gbmpfba_df2.columns]

gbm_tasks_gp = gbm_tasks_df2.groupby(level=0).sum()
hb_tasks_gp = hb_tasks_df.groupby(level=0).sum()
hb_hb_tasks_gp = hb_tasks_df.iloc[:,9:22].groupby(level=0).sum()
md_tasks_gp = md_tasks_df.groupby(level=0).sum()

#General Boxplot
fig1, ax1 = plt.subplots()
ax1.set_title('Tasks Passed')
ax1.boxplot([gbm_tasks_gp.sum(),hb_tasks_gp.sum(),
             hb_hb_tasks_gp.sum()],labels=["GBM","HT","HB"])
ax1.set_ylabel('Task Count')

print("GBM Tasks Passed %:",round(gbm_tasks_gp.sum().mean()/210*100,2),"\n"
      "HT Tasks Passed %:",round(hb_tasks_gp.sum().mean()/210*100,2),"\n"
      "HB Tasks Passed %:",round(hb_hb_tasks_gp.sum().mean()/210*100,2))

#General boxplot - More data
fig1, ax1 = plt.subplots() 
# ax1.set_title('Tasks Passed')
ax1.boxplot([md_tasks_gp.iloc[:,:2].sum(),md_tasks_gp.iloc[:,2:].sum()],
            labels=["GBM","AST"])
ax1.set_ylabel('Task Count')
ax1.set_ylim(40,180)

print("GBM Tasks Passed %:",round(md_tasks_gp.iloc[:,:2].sum().mean()/210*100,2),"\n",
      "AST Tasks Passed %:",round(md_tasks_gp.iloc[:,2:].sum().mean()/210*100,2))

#% by pathway
gbm_tasks_gp_pw = np.sum(gbm_tasks_gp,axis=1)/np.sum(gbm_tasks_gp,axis=1).sum()*100
hb_tasks_gp_pw = np.sum(hb_tasks_gp,axis=1)/np.sum(hb_tasks_gp,axis=1).sum()*100
hb_hb_tasks_gp_pw = np.sum(hb_hb_tasks_gp,axis=1)/np.sum(hb_hb_tasks_gp,axis=1).sum()*100

md_gbm_tasks_gp_pw = np.sum(md_tasks_gp.iloc[:,:2],axis=1)/np.sum(md_tasks_gp.iloc[:,:2],axis=1).sum()*100
md_hb_tasks_gp_pw = np.sum(md_tasks_gp.iloc[:,2:],axis=1)/np.sum(md_tasks_gp.iloc[:,2:],axis=1).sum()*100

#top and bottom % pathways
print(gbm_tasks_gp_pw.sort_values(ascending=False))
print(hb_tasks_gp_pw.sort_values(ascending=False))
print(hb_hb_tasks_gp_pw.sort_values(ascending=False))

print(md_gbm_tasks_gp_pw.sort_values(ascending=False))
print(md_hb_tasks_gp_pw.sort_values(ascending=False))

#pathways >= 2% threshold
common = [gbm_tasks_gp_pw.iloc[np.where(gbm_tasks_gp_pw>=2)[0]].index,
          hb_tasks_gp_pw.iloc[np.where(hb_tasks_gp_pw>=2)[0]].index,
          hb_hb_tasks_gp_pw.iloc[np.where(hb_hb_tasks_gp_pw>=2)[0]].index,
          md_gbm_tasks_gp_pw.iloc[np.where(md_gbm_tasks_gp_pw>=2)[0]].index,
          md_hb_tasks_gp_pw.iloc[np.where(md_hb_tasks_gp_pw>=2)[0]].index]
common2 = (common[0] & common[1] & common[2] & common[3] & common[4])
print([len(x) for x in common])

print(gbm_tasks_gp_pw.iloc[np.where(gbm_tasks_gp_pw>=2)[0]],end="\n\n")
print(hb_tasks_gp_pw.iloc[np.where(hb_tasks_gp_pw>=2)[0]],end="\n\n")
print(hb_hb_tasks_gp_pw.iloc[np.where(hb_hb_tasks_gp_pw>=2)[0]],end="\n\n")

print(md_gbm_tasks_gp_pw.iloc[np.where(md_gbm_tasks_gp_pw>=2)[0]],end="\n\n")
print(md_hb_tasks_gp_pw.iloc[np.where(md_hb_tasks_gp_pw>=2)[0]])

#pathway % Barplot
colors=["lightsteelblue","cornflowerblue","springgreen","mediumseagreen","gold"]
fig1, ax1 = plt.subplots(5,1, figsize = (20,13.5),sharex=True)
ax1[0].set_title('Tasks Passed by Pathway\nGDC GBM')
ax1[1].set_title('HT')
ax1[2].set_title('HB')
ax1[3].set_title('AE GBM')
ax1[4].set_title('AST')

ax1[0].bar(hb_hb_tasks_gp_pw.index,list(gbm_tasks_gp_pw),color=colors[0])
ax1[1].bar(hb_hb_tasks_gp_pw.index,list(hb_tasks_gp_pw),color=colors[1])
ax1[2].bar(hb_hb_tasks_gp_pw.index,list(hb_hb_tasks_gp_pw),color=colors[2],align="center")
ax1[3].bar(md_gbm_tasks_gp_pw.index,list(md_gbm_tasks_gp_pw),color=colors[0])
ax1[4].bar(md_hb_tasks_gp_pw.index,list(md_gbm_tasks_gp_pw),color=colors[-1])
ax1[0].set_xticklabels([], rotation=90)
ax1[1].set_xticklabels([], rotation=90)
ax1[2].set_xticklabels([], rotation=90)
ax1[3].set_xticklabels([], rotation=90)
ax1[4].set_xticklabels(hb_hb_tasks_gp.index, rotation=90) 
# plt.rcParams['xtick.labelsize'] = 8

ax1[0].set_ylabel('Task Count %')
ax1[1].set_ylabel('Task Count %')
ax1[2].set_ylabel('Task Count %')
ax1[3].set_ylabel('Task Count %')
ax1[4].set_ylabel('Task Count %')
ax1[0].set_ylim(0,13)
ax1[1].set_ylim(0,13)
ax1[2].set_ylim(0,13)
ax1[3].set_ylim(0,13)
ax1[4].set_ylim(0,13)
ax1[0].hlines(y=2,xmin=-2,xmax=len(hb_hb_tasks_gp_pw.index)+1,lw=1)
ax1[0].text(-3, 2.8, 'y = 2%', ha='left', va='center')
ax1[1].hlines(y=2,xmin=-2,xmax=len(hb_hb_tasks_gp_pw.index)+1,lw=1)
ax1[1].text(-3, 2.8, 'y = 2%', ha='left', va='center')
ax1[2].hlines(y=2,xmin=-2,xmax=len(hb_hb_tasks_gp_pw.index)+1,lw=1)
ax1[2].text(-3, 2.8, 'y = 2%', ha='left', va='center')
ax1[3].hlines(y=2,xmin=-2,xmax=len(md_gbm_tasks_gp_pw.index)+1,lw=1)
ax1[3].text(-3, 2.8, 'y = 2%', ha='left', va='center')
ax1[4].hlines(y=2,xmin=-2,xmax=len(md_gbm_tasks_gp_pw.index)+1,lw=1)
ax1[4].text(-3, 2.8, 'y = 2%', ha='left', va='center')


######### METADATA #########
metagbm = pd.read_csv(META_GBM_PATH,header=0)        
metaheader = list(metagbm.columns.values)

#matching data to kept models
metagbm_slim = metagbm.iloc[gbmpfba_df2.columns,:]

print(metagbm_slim["demographic.gender"].value_counts())
print(metagbm_slim["demographic.vital_status"].value_counts())
F = metagbm_slim.loc[metagbm_slim["demographic.gender"]=="female"]
M = metagbm_slim.loc[metagbm_slim["demographic.gender"]=="male"]
f_status = F["demographic.vital_status"].value_counts() 
m_status = M["demographic.vital_status"].value_counts()

f_ind = np.where(gbmpfba_df2.columns.isin(F.index)==True)[0]
m_ind = np.where(gbmpfba_df2.columns.isin(M.index)==True)[0]
fmodels = gbmpfba_df2.iloc[:,f_ind] 
mmodels = gbmpfba_df2.iloc[:,m_ind]

print("Average F Biomass:", round(fmodels.iloc[5440,:].mean(),2))
print("Average M Biomass:",round(mmodels.iloc[5440,:].mean(),2))

print("Average F Lactate Drain:",
      round(fmodels.iloc[reaction_ids.index("LDH_L"),:].mean(),2))
print("Average M Lactate Drain:",
      round(mmodels.iloc[reaction_ids.index("LDH_L"),:].mean(),2))

print("Average F PDH:",
      round(fmodels.iloc[reaction_ids.index("PDHm"),:].mean(),2))
print("Average M PDH:",
      round(mmodels.iloc[reaction_ids.index("PDHm"),:].mean(),2))

fmodels_abs = pd.DataFrame(fmodels.abs(),index=subsystems)
mmodels_abs = pd.DataFrame(mmodels.abs(),index=subsystems)
fmodels_gp = fmodels_abs.groupby(level=0).sum()
mmodels_gp = mmodels_abs.groupby(level=0).sum()

print("Average F ROS detoxification Activity (Hundreds):",
      round(fmodels_gp.loc["ROS detoxification",:].mean()/100,2))
print("Average M ROS detoxification Activity:",
      round(mmodels_gp.loc["ROS detoxification",:].mean()/100,2))
print("Average F Fatty acid synthesis Activity:",
      round(fmodels_gp.loc["Fatty acid synthesis",:].mean()/100,2))
print("Average M Fatty acid synthesis Activity:",
      round(mmodels_gp.loc["Fatty acid synthesis",:].mean()/100,2))

print("Average F GLYC Activity (Hundreds):",
      round(fmodels_gp.loc["Glycolysis/gluconeogenesis",:].mean()/100,2))
print("Average M GLYC Activity:",
      round(mmodels_gp.loc["Glycolysis/gluconeogenesis",:].mean()/100,2))
print("Average F TCA Activity:",
      round(fmodels_gp.loc["Citric acid cycle",:].mean()/100,2))
print("Average M TCA Activity:",
      round(mmodels_gp.loc["Citric acid cycle",:].mean()/100,2))
print("Average F OXPP Activity:",
      round(fmodels_gp.loc["Oxidative phosphorylation",:].mean()/100,2))
print("Average M OXPP Activity:",
      round(mmodels_gp.loc["Oxidative phosphorylation",:].mean()/100,2))
print("Average F PPP Activity:",
      round(fmodels_gp.loc["Pentose phosphate pathway",:].mean()/100,2))
print("Average M PPP Activity:",
      round(mmodels_gp.loc["Pentose phosphate pathway",:].mean()/100,2))

###
metagbm_slim["demographic.race"].value_counts()
f_race = F["demographic.race"].value_counts() 
m_race = M["demographic.race"].value_counts()

# all patients
# pd.DataFrame(metagbm["diagnoses.age_at_diagnosis"]/365).describe()
# only deceased
dead = metagbm_slim.loc[metagbm_slim["demographic.vital_status"]=="Dead"]
age = dead["demographic.year_of_death"]-dead["demographic.year_of_birth"]
print(age.describe())

#Pie charts
#Gender / Vital Status
fig1, ax1 = plt.subplots(2,2, figsize = (10,10))
ax1[0,0].set_title('Gender')
ax1[0,1].set_title('Vital Status')
ax1[1,0].set_title('Vital Status by Gender - F')
ax1[1,1].set_title('Vital Status by Gender - M')
ax1[0,0].pie(list(metagbm_slim["demographic.gender"].value_counts()),autopct='%1.1f%%',
           labels=list(metagbm_slim["demographic.gender"].value_counts().index))
ax1[0,1].pie(list(metagbm_slim["demographic.vital_status"].value_counts()),autopct='%1.1f%%',
           labels=list(metagbm_slim["demographic.vital_status"].value_counts().index))
ax1[1,0].pie(list(f_status),labels=list(f_status.index),autopct='%1.1f%%')
ax1[1,1].pie(list(m_status),labels=list(m_status.index),autopct='%1.1f%%')

# Race / vital status
fig1, ax1 = plt.subplots(3,1, figsize = (5,13))
ax1[0].set_title('Race')
ax1[1].set_title('Race by Gender - F')
ax1[2].set_title('Race by Gender - M')

ax1[0].pie(list(metagbm_slim["demographic.race"].value_counts()),autopct='%1.1f%%',
           labels=list(metagbm_slim["demographic.race"].value_counts().index))
ax1[1].pie(list(f_race),autopct='%1.1f%%',labels=list(f_race.index))
ax1[2].pie(list(m_race),autopct='%1.1f%%',labels=list(m_race.index))

f_age = F["diagnoses.age_at_diagnosis"]/365 
m_age = M["diagnoses.age_at_diagnosis"]/365 
print(f_age.describe())
print(m_age.describe())

#Age Histogram
temp = metagbm_slim[metagbm_slim['diagnoses.age_at_diagnosis'].notnull()]
temp = temp['diagnoses.age_at_diagnosis']/365

fig1, ax1 = plt.subplots(1,1, figsize = (10,7)) 
ax1.hist(list(temp),bins=8,color="lightsteelblue")
temp.plot(kind='kde', ax=ax1,secondary_y=True)
plt.ylabel("Kernel Density Estimation")
ax1.set_xlabel("Age (years)")
ax1.set_ylabel("Density")
ax1.set_xlim(0,100)
# metagbm[metagbm['diagnoses.age_at_diagnosis'].notnull()]
