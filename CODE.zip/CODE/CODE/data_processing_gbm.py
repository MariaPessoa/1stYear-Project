# -*- coding: utf-8 -*-
"""
Created on Wed Apr 29 13:16:47 2020

@author: Maria Pessoa Monteiro
"""
import pandas as pd
import numpy as np
import csv

ROOT_FOLDER = "C:\\Users\\liamo\\Documents\\BIOINF\\PROJ"  
DATA_PATH = ROOT_FOLDER + "\\TCGA-GBM\\GEQ\\Datasets\\geq_data.csv"
IDS_PATH = ROOT_FOLDER + "\\files\\gene_ids_edit.csv"
OUT_PATH = ROOT_FOLDER + "\\files\\geq_data_CLEAN_log2_june.csv"
 
id_mat = np.array(pd.read_csv(IDS_PATH,header=0,sep=";")) #(41818, 10) 

dataread = pd.read_csv(DATA_PATH,header=0) 
dheader = list(dataread.columns.values)[2:]
data_mat = np.array(dataread)[:,2:]
numrow, numcol = data_mat.shape #(174, 60483)

to_delete = []
means = []
reads_header = [] 
        
#convert Ensembl ids to Entrez  
for h in range(len(dheader)): 
    if dheader[h] in id_mat[:,4]: #only found match in Ensembl ids
        rowindex = list(np.where(id_mat[:,4] == dheader[h])[0])
        if len(rowindex) > 0 and len(str(id_mat[rowindex[0],3]).split(".")[0]) > 0:
            if str(id_mat[rowindex[0],3]).split(".")[0] not in reads_header:
                #remove extra from "EntrezId.extra"
                 reads_header.append(str(id_mat[rowindex[0],3]).split(".")[0])
            else: to_delete.append(h)
        else: to_delete.append(h)
    else: to_delete.append(h)
print("Finished converting ids")

print(len(reads_header),len(set(reads_header))) #checking for repeats
print("Kept id %:",round((len(dheader)-len(to_delete))/len(dheader)*100))

for h in range(numcol): 
    if h not in to_delete: 
        if (sum(data_mat[:,h]) > 0): 
            means.append(sum(data_mat[:,h])/numrow)    
        else: means.append(0) #unexpressed genes

reads = np.delete(data_mat,to_delete,1) #delete cols without EntrezIds    
del data_mat #save memory
print("reads:",reads.shape)
# print(len(reads_header),len(means))
numrow, numcol = reads.shape

for r in range(numrow): 
    for c in range(numcol):  #normalization
        if means[c] > 0:
            quantiles = list(np.quantile(reads[:,c],[0.25,0.75]))
            if quantiles[0] > 0 and quantiles[1] > 0:
                if means[c] <= quantiles[0]: #quantile 25
                    reads[r,c] = 5*np.log2(1+(reads[r,c]/quantiles[0]))
                elif means[c] >= quantiles[1]: #quantile 75
                    reads[r,c] = 5*np.log2(1+(reads[r,c]/quantiles[1]))
                else: reads[r,c] = 5*np.log2(1+(reads[r,c]/means[c]))
            else: reads[:,c] = 0
print("Finished processing reads")

# Adding index / model id col
# reads_header2 = np.array(reads_header).reshape(1,len(reads_header))
# print(reads_header2.shape)
reads_header.insert(0,"Samples")
samples = []
for i in range(1,reads.shape[0]+1): samples.append("Model_"+str(i))
samples =  np.array(samples).reshape(len(samples),1)
print(samples.shape)
print(reads.shape)
all_cl = np.concatenate((samples,reads),axis=1)
print(all_cl.shape)

#pandas csv writer, 1a coluna com nomes de samples
with open(OUT_PATH,"w") as outfile:
    writer = csv.writer(outfile,delimiter=",")
    writer.writerow(np.array(reads_header)) #sample rows x gene cols
    for r in range(all_cl.shape[0]): writer.writerow(all_cl[r,:])

gbm = pd.read_csv(OUT_PATH,header=0).iloc[:,1:]
unexp = np.where(gbm.sum()==0)[0]
print("Unexpressed %:",round(len(unexp)/len(dheader)*100))

